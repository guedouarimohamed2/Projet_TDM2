package com.tdm2serie2ex4.master.projet_tdm2.Model

data class RSSObject(val status:String,val feed:Feed,val items:List<Item>) {
}