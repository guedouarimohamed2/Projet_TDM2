package com.tdm2serie2ex4.master.projet_tdm2.Adapter

import android.content.Context
import android.content.Intent
import android.support.v4.content.LocalBroadcastManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.tdm2serie2ex4.master.projet_tdm2.Interface.IItemClickListener
import com.tdm2serie2ex4.master.projet_tdm2.MainActivity
import com.tdm2serie2ex4.master.projet_tdm2.Model.RSSObject
import com.tdm2serie2ex4.master.projet_tdm2.R

class MyViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
    internal var text_wilaya: TextView
    internal var text_type: TextView
    internal var text_nom: TextView
    internal lateinit var btn : Button
    internal var itemClickListener: IItemClickListener?=null

    fun setItemClickListener(itemClickListener:IItemClickListener)
    {
        this.itemClickListener = itemClickListener
    }
    init {
        text_nom = itemView.findViewById(R.id.nom) as TextView
        text_type = itemView.findViewById(R.id.type) as TextView
        text_wilaya = itemView.findViewById(R.id.wilaya) as TextView
        btn =  itemView.findViewById(R.id.btn_save) as Button
        itemView.setOnClickListener{view -> itemClickListener!!.onclick(view,adapterPosition)}

    }
}

class AnnonceListAdapter (private val context: Context,
                          private val rssObject: RSSObject): RecyclerView.Adapter<MyViewHolder>(){
    private val inflater:LayoutInflater;
    init {
        inflater = LayoutInflater.from(context)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = inflater.inflate(R.layout.annonce_item,parent,false)
        return MyViewHolder(itemView)
    }

    override fun getItemCount(): Int {
        return rssObject.items.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.text_nom.text= rssObject.items[position].title
        holder.text_type.text=rssObject.items[position].content
        holder.text_wilaya.text=rssObject.items[position].pubDate

        holder.setItemClickListener(object :IItemClickListener{

            override fun onclick(view: View, position: Int) {
//                LocalBroadcastManager.getInstance(context)
//                        .sendBroadcast(Intent("position").putExtra("title",rssObject.items[position].title))
                Toast.makeText(context, "Hi there! This is a Toast.", Toast.LENGTH_SHORT).show()
            }
        })

        holder.btn.setOnClickListener {
            val activity: MainActivity = context as MainActivity
            // LocalBroadcastManager.getInstance(context)
            Toast.makeText(context, "Click!", Toast.LENGTH_SHORT).show();



            // Toast.makeText(Activity(), "Click!", Toast.LENGTH_SHORT).show();

        }
    }

}