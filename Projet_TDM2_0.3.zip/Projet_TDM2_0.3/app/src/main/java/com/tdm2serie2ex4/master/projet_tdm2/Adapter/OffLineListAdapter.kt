package com.tdm2serie2ex4.master.projet_tdm2.Adapter

import android.content.Context
import android.content.Intent
import android.support.v4.content.LocalBroadcastManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import com.tdm2serie2ex4.master.projet_tdm2.Interface.IItemClickListener
import com.tdm2serie2ex4.master.projet_tdm2.Model.Annonce
import com.tdm2serie2ex4.master.projet_tdm2.Model.AnnonceSaved
import com.tdm2serie2ex4.master.projet_tdm2.R

class OffLineListAdapter(internal var context: Context,
                         internal var annonceList:MutableList<Annonce>): RecyclerView.Adapter<OffLineListAdapter.MyViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        var itemView = LayoutInflater.from(context).inflate(R.layout.annonce_off_line_item,parent,false)
        return MyViewHolder(itemView)
    }

    override fun getItemCount(): Int {
        return annonceList.size
    }

    override fun onBindViewHolder(holder: OffLineListAdapter.MyViewHolder, position: Int) {
        holder.text_nom.text= annonceList[position].nom
        holder.text_type.text=annonceList[position].type
        holder.text_wilaya.text=annonceList[position].wilaya


        holder.setItemClickListener(object :IItemClickListener{

            override fun onclick(view: View, position: Int) {
//                LocalBroadcastManager.getInstance(context)
//                        .sendBroadcast(Intent(AnnonceSaved.KEY_ENABLE_HOME).putExtra("nom",annonceList[position].nom))
                Toast.makeText(context, annonceList[position].nom, Toast.LENGTH_SHORT).show()
            }
        })
    }

    inner class MyViewHolder(itemView: View):RecyclerView.ViewHolder(itemView){
        internal var text_wilaya: TextView
        internal var text_type: TextView
        internal var text_nom: TextView
        internal var itemClickListener: IItemClickListener?=null

        fun setItemClickListener(itemClickListener: IItemClickListener)
        {
            this.itemClickListener = itemClickListener
        }

        init {
            text_nom = itemView.findViewById(R.id.nom) as TextView
            text_type = itemView.findViewById(R.id.type) as TextView
            text_wilaya = itemView.findViewById(R.id.wilaya) as TextView
            itemView.setOnClickListener{view -> itemClickListener!!.onclick(view,adapterPosition)}
        }
    }
}