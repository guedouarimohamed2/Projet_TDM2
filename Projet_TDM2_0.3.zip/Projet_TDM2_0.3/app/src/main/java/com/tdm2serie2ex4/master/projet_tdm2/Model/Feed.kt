package com.tdm2serie2ex4.master.projet_tdm2.Model

data class Feed(val url:String,val title:String,val link:String,val author:String,val description:String,val image:String) {
}