package com.tdm2serie2ex4.master.projet_tdm2.Model

import android.net.Uri
import java.util.ArrayList

class Annonce (var nom:String?=null,
               var type:String?=null,
               var wilaya:String?=null,
               var description:String?=null,
               var telephone:String?=null,
               var email:String?=null,
               var date_depot: Long? =null
) {
}