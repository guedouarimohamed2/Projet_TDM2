package com.tdm2serie2ex4.master.projet_tdm2.Interface

import android.view.View

interface IItemClickListener {
    fun onclick(view: View, position:Int )
}